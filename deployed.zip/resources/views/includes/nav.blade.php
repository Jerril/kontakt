<nav>
    <a href="/" class="logo">kòntakts</a>
</nav>
