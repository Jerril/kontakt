<nav>
    <a href="/" class="logo">kòntakts</a>

    <?php if(auth()->user()): ?>
        <div>
            <a href="/login" class="login">Go to Dashboard <i class="fas fa-arrow-up"></i></a>
        </div>
    <?php else: ?>
        <div>
            <a href="/login" class="login">Login <i class="fas fa-arrow-up"></i></a>
            <a href="/signup" class="signup">Sign up</a>
        </div>
    <?php endif; ?>
</nav>
<?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/includes/nav-index.blade.php ENDPATH**/ ?>