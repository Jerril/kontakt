<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <nav>
        <a href="/" class="logo">kòntakts</a>
    </nav>

    <main>
        <h2>Sign up</h2>
        <form action="">
            <input class="name" type="text" placeholder="Name">
            <input class="email" type="email" placeholder="Email" />
            <input class="password" type="password" placeholder="Password" />
            <input type="submit" value="Create account">
        </form>

        <p>Have an account? <a href="/login">Login</a></p>
    </main>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/signup.blade.php ENDPATH**/ ?>