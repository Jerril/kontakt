<nav>
    <a href="/" class="logo">kòntakts</a>
</nav>
<?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/includes/nav.blade.php ENDPATH**/ ?>