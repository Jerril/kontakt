<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Session::has('msg')): ?>
        <div role="alert" class="w-1/2 bg-teal-100 text-center rounded px-4 py-2 mt-4 mx-auto">
            <p><?php echo e(Session::get('msg')); ?></p>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div role="alert" class="w-1/2 bg-red-400 text-white text-center rounded px-4 py-2 mt-4 mx-auto">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <main>
        <h2>Login</h2>
        <form method="POST" action="<?php echo e(route('login.post')); ?>">
            <?php echo csrf_field(); ?>
            <input name="email" type="email" placeholder="Email" />
            <input name="password" type="password" placeholder="Password" />
            <input type="submit" value="Login">
        </form>

        <p>New here? <a href="/signup">Sign up</a></p>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/pages/login.blade.php ENDPATH**/ ?>