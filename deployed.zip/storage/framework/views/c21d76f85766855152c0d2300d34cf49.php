<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <nav>
        <a href="/" class="logo">kòntakts</a>
        <div>
            <a href="/login" class="login">Login <i class="fas fa-arrow-up"></i></a>
            <a href="/signup" class="signup">Sign up</a>
        </div>
    </nav>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/homepage.blade.php ENDPATH**/ ?>