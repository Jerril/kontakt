<?php if(!auth()->user()): ?>
    <?php echo e(redirect('/login')); ?>

<?php endif; ?>



<?php $__env->startSection('content'); ?>
    <div class="dashboard">
        <div class="sidebar">
            <div>
                <a href="/" class="logo">kòntakts</a>

                <button class="add-contact" data-toggle="modal" data-target="#addContactModal">
                    + Add contact
                </button>

                <div class="groups">
                    <p>Groups <span title="Create group" data-toggle="modal" data-target="#addGroupModal">+</span></p>

                    <?php if(!$groups->isEmpty()): ?>
                    <ul>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a title="Delete group" href="<?php echo e(route('group.delete', ['group' => $group->id])); ?>"><i class="fa fa-trash-alt"></i></a> &nbsp; <?php echo e($group->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                        <p style="font-size:14px; font-weight:500" class="bg-yellow-100 rounded text-black text-center my-3 py-1">No groups created yet</p>
                    <?php endif; ?>
                </div>
            </div>

            <div>
            </div>

            <div>
                <p class="profile"><span></span>Hello! <?php echo e(auth()->user()->name); ?></p>
                <a href="<?php echo e(route('logout')); ?>" class="logout"><i class="fas fa-arrow-right"></i> Logout</a>
            </div>
        </div>

        <div class="main">
            <div class="heading">
                <div class="search">
                    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="search-bar">
                        <input type="text" class="rounded-s" name="s" placeholder="Type here..."/>
                        <div class="btns">
                            <input class="submit rounded-e" type="submit" value="Search" />
                            
                        </div>

                    </form>
                </div>
                <div class="export" title='Export'>
                    <i class="fas fa-print"></i>
                </div>
            </div>
            <section>
                <?php if(Session::has('msg')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e(Session::get('msg')); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(!$contacts->isEmpty()): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Address</th>
                            <th>Group</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="contact-name">
                                    <div class="img">
                                    <?php if($contact->avatar): ?>
                                        <img src="<?php echo e(asset('storage/'.$contact->avatar) ?? ''); ?>" alt="">
                                    <?php endif; ?>
                                    </div>
                                    <p><?php echo e($contact->name ?? ''); ?></p>
                                </td>
                                <td><?php echo e($contact->email ?? ''); ?></td>
                                <td><?php echo e($contact->phone_number ?? '---'); ?></td>
                                <td><?php echo e($contact->address ?? '---'); ?></td>
                                <td>
                                    <?php if($contact->group): ?>
                                    <span style="font-size:11px; font-weight:700" class="bg-green-500 text-white px-2 py-1 rounded"><?php echo e($contact->group->name); ?></span>
                                    <?php else: ?>
                                    ---
                                    <?php endif; ?>
                                </td>
                                <td><i class="fa fa-edit" data-toggle="modal" data-target="#editContactModal<?php echo e($contact->id); ?>"></i><a href="<?php echo e(route('contact.delete', ['contact' => $contact->id])); ?>"><i class="fa fa-trash-alt"></i></a></td>
                            </tr>
                            
                            <div class="modal fade" id="editContactModal<?php echo e($contact->id); ?>" tabindex="-1" aria-labelledby="editContactModalLabel<?php echo e($contact->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title text-center" id="editContactModalLabel<?php echo e($contact->id); ?>">Edit Contact</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('contact.put', ['contact' => $contact->id])); ?>">
                                        <?php echo method_field('PUT'); ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="contact-name" class="col-form-label">Name</label>
                                                <input type="text" name="name" class="form-control" id="contact-name" value="<?php echo e($contact->name); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="contact-email" class="col-form-label">Email</label>
                                                <input type="text" name="email" class="form-control" id="contact-email"  value="<?php echo e($contact->email); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="contact-phoneno" class="col-form-label">Phone Number</label>
                                                <input type="text" name="phone_number" class="form-control" id="contact-phoneno" value="<?php echo e($contact->phone_number ?? ''); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="address" class="col-form-label">Address</label>
                                                <input type="text" name="address" class="form-control" id="address" value="<?php echo e($contact->address ?? ''); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="group" class="col-form-label">Select group</label>
                                                <select name="group_id" id="group">
                                                    <option value="">pick one...</option>
                                                    <?php if(!$groups->isEmpty()): ?>
                                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn bg-primary btn-primary">Update Contact</button>
                                        </div>
                                    </form>
                                </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div role="alert" class="w-1/2 bg-yellow-100 text-center text-black rounded px-4 py-2 mt-4 mx-auto">
                        <p style="font-weight:500" class="text-center">No contacts created yet</p>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>

    
    <div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="addContactModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title text-center" id="addContactModalLabel">Create Contact</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <form method="POST" action="<?php echo e(route('contact.post')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="contact-name" class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="contact-name" required>
                    </div>
                    <div class="form-group">
                        <label for="contact-email" class="col-form-label">Email</label>
                        <input type="text" name="email" class="form-control" id="contact-email" required>
                    </div>
                    <div class="form-group">
                        <label for="contact-phoneno" class="col-form-label">Phone Number</label>
                        <input type="text" name="phone_number" class="form-control" id="contact-phoneno">
                    </div>
                    <div class="form-group">
                        <label for="address" class="col-form-label">Address</label>
                        <input type="text" name="address" class="form-control" id="address">
                    </div>
                    <div class="form-group">
                        <label for="avatar" class="col-form-label">Upload Avatar</label>
                        <input type="file" name="avatar" class="form-control" id="avatar">
                    </div>
                    <div class="form-group">
                        <label for="group" class="col-form-label">Select group</label>
                        <select name="group_id" id="group">
                            <option value="">pick one...</option>
                            <?php if(!$groups->isEmpty()): ?>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn bg-primary btn-primary">Add Contact</button>
                </div>
            </form>
        </div>
        </div>
    </div>

    
    <div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title text-center" id="addGroupModalLabel">Create Group</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <form method="POST" action="<?php echo e(route('group.post')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="group-name" class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="group-name" required>
                    </div>
                    <div class="form-group">
                        <label for="group-description" class="col-form-label">Description</label>
                        <input type="text" name="description" class="form-control" id="group-description">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn bg-primary btn-primary">Add Group</button>
                </div>
            </form>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oawonusi\Desktop\kontakt\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>